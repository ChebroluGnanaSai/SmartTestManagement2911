"""
blob_storage.py — everything Azure Blob Storage related lives here, kept
separate from main.py so the app logic (routes) stays readable.

Handles: container creation, upload, download, delete, and generating
time-limited SAS share links.
"""

import os
from datetime import datetime, timedelta, timezone
from urllib.parse import urlparse

from azure.storage.blob import (
    BlobSasPermissions,
    BlobServiceClient,
    ContentSettings,
    generate_blob_sas,
)
from dotenv import load_dotenv

load_dotenv()

AZURE_STORAGE_CONNECTION_STRING = os.environ["AZURE_STORAGE_CONNECTION_STRING"]
AZURE_CONTAINER_NAME = os.environ["AZURE_CONTAINER_NAME"]

blob_service_client = BlobServiceClient.from_connection_string(
    AZURE_STORAGE_CONNECTION_STRING
)


def _parse_connection_string(conn_str: str) -> dict:
    """Pulls out key=value pairs (AccountName, AccountKey, ...) from a
    standard Azure Storage connection string."""
    parts = {}
    for item in conn_str.split(";"):
        if "=" in item:
            key, _, value = item.partition("=")
            parts[key.strip()] = value
    return parts


_conn_parts = _parse_connection_string(AZURE_STORAGE_CONNECTION_STRING)
ACCOUNT_NAME = _conn_parts.get("AccountName")
ACCOUNT_KEY = _conn_parts.get("AccountKey")


def init_container():
    """Creates the blob container if it doesn't exist yet."""
    container_client = blob_service_client.get_container_client(AZURE_CONTAINER_NAME)
    if not container_client.exists():
        container_client.create_container()


def upload_file(blob_name: str, file_bytes: bytes, content_type: str) -> str:
    """Uploads a file to the container and returns its blob URL."""
    blob_client = blob_service_client.get_blob_client(
        container=AZURE_CONTAINER_NAME, blob=blob_name
    )
    blob_client.upload_blob(
        file_bytes,
        overwrite=True,
        content_settings=ContentSettings(content_type=content_type),
    )
    return blob_client.url


def download_file(blob_name: str) -> bytes:
    """Downloads a blob's raw bytes."""
    blob_client = blob_service_client.get_blob_client(
        container=AZURE_CONTAINER_NAME, blob=blob_name
    )
    return blob_client.download_blob().readall()


def delete_file(blob_name: str) -> None:
    """Deletes a blob from the container."""
    blob_client = blob_service_client.get_blob_client(
        container=AZURE_CONTAINER_NAME, blob=blob_name
    )
    blob_client.delete_blob()


def generate_share_link(blob_name: str, expiry_minutes: int) -> tuple[str, datetime]:
    """Generates a secure, time-limited SAS URL for a blob.

    The link is read-only and automatically stops working once the expiry
    timestamp passes, since Azure Storage rejects SAS tokens whose `se`
    (signed expiry) parameter is in the past — no cleanup job needed.
    """
    if not ACCOUNT_NAME or not ACCOUNT_KEY:
        raise RuntimeError(
            "AZURE_STORAGE_CONNECTION_STRING must include AccountName and "
            "AccountKey to generate SAS URLs."
        )

    expiry_time = datetime.now(timezone.utc) + timedelta(minutes=expiry_minutes)

    sas_token = generate_blob_sas(
        account_name=ACCOUNT_NAME,
        container_name=AZURE_CONTAINER_NAME,
        blob_name=blob_name,
        account_key=ACCOUNT_KEY,
        permission=BlobSasPermissions(read=True),
        expiry=expiry_time,
    )

    blob_client = blob_service_client.get_blob_client(
        container=AZURE_CONTAINER_NAME, blob=blob_name
    )
    share_url = f"{blob_client.url}?{sas_token}"
    return share_url, expiry_time


def blob_name_from_url(blob_url: str) -> str:
    """Extracts the blob name (path within the container) from a full blob
    URL, so download/delete/share can look the blob back up by document."""
    path = urlparse(blob_url).path  # /<container>/<blob_name>
    prefix = f"/{AZURE_CONTAINER_NAME}/"
    return path[len(prefix):] if path.startswith(prefix) else path.lstrip("/")
