"""
database.py — Azure SQL Database connection and the Document model.

Kept separate from main.py so the app logic (routes) stays readable.

Uses pymssql instead of pyodbc/ODBC Driver 18 — pymssql is pure
pip-installable (bundles its own driver internals), so there's no
Homebrew/system ODBC driver step required to connect to Azure SQL Database.
"""

import os
from datetime import datetime

from dotenv import load_dotenv
from sqlalchemy import Column, DateTime, Integer, String, create_engine
from sqlalchemy.orm import declarative_base, sessionmaker

load_dotenv()

# Expected format:
# mssql+pymssql://<username>:<password>@<server>.database.windows.net:1433/<database>
AZURE_SQL_CONNECTION_STRING = os.environ["AZURE_SQL_CONNECTION_STRING"]

engine = create_engine(AZURE_SQL_CONNECTION_STRING, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base = declarative_base()


class Document(Base):
    """Matches the `Documents` table required by the project spec:
    document_id, file_name, blob_url, uploaded_by, upload_date, file_type.
    """

    __tablename__ = "documents"

    document_id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    file_name = Column(String(255), nullable=False)
    blob_url = Column(String(1000), nullable=False)
    uploaded_by = Column(String(200), nullable=False)
    upload_date = Column(DateTime, default=datetime.utcnow, nullable=False)
    file_type = Column(String(100), nullable=False)


def init_db():
    """Creates the documents table if it doesn't exist yet."""
    Base.metadata.create_all(bind=engine)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
