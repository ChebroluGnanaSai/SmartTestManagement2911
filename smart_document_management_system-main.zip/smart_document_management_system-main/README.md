# Smart Document Management System

A FastAPI application that lets users upload documents, storing the file in
**Azure Blob Storage** and its metadata in **Azure SQL Database**, then view,
download, securely share (time-limited SAS link), and delete those documents.

## Architecture

| Requirement | Implementation |
|---|---|
| Upload document | `POST /documents/upload` — file goes to Blob Storage, metadata row goes to Azure SQL |
| View all documents | `GET /documents` |
| View document by ID | `GET /documents/{document_id}` |
| Download document | `GET /documents/{document_id}/download` |
| Generate secure share link | `POST /documents/{document_id}/share` — returns a SAS URL that expires after the requested duration |
| Delete document | `DELETE /documents/{document_id}` — removes blob + SQL row |

Project layout:

```
document-management-system/
├── main.py           # FastAPI routes
├── database.py        # Azure SQL Database connection + Document model
├── blob_storage.py     # Azure Blob Storage operations (upload/download/delete/SAS)
├── schemas.py         # Pydantic request/response models
├── requirements.txt
├── .env.example
└── README.md
```

## Database Schema

`documents` table (Azure SQL Database):

| Column | Type |
|---|---|
| document_id | INT (identity, primary key) |
| file_name | VARCHAR |
| blob_url | VARCHAR |
| uploaded_by | VARCHAR |
| upload_date | DATETIME |
| file_type | VARCHAR |

The table is created automatically on startup (`init_db()` in `database.py`).

---

## 1. Create Azure Resources

You can create these in the Azure Portal, or with the Azure CLI:

```bash
# 1. Resource group
az group create --name doc-mgmt-rg --location eastus

# 2. Storage account + blob container
az storage account create \
  --name docmgmtstorage<unique-suffix> \
  --resource-group doc-mgmt-rg \
  --location eastus \
  --sku Standard_LRS

az storage container create \
  --account-name docmgmtstorage<unique-suffix> \
  --name documents

# 3. Azure SQL logical server + database
az sql server create \
  --name doc-mgmt-sqlserver<unique-suffix> \
  --resource-group doc-mgmt-rg \
  --location eastus \
  --admin-user sqladmin \
  --admin-password "<StrongPassword123!>"

az sql db create \
  --resource-group doc-mgmt-rg \
  --server doc-mgmt-sqlserver<unique-suffix> \
  --name doc-mgmt-db \
  --service-objective S0

# Allow your client IP (and Azure services, for optional App Service deployment)
az sql server firewall-rule create \
  --resource-group doc-mgmt-rg \
  --server doc-mgmt-sqlserver<unique-suffix> \
  --name AllowMyIP \
  --start-ip-address <your-ip> \
  --end-ip-address <your-ip>

az sql server firewall-rule create \
  --resource-group doc-mgmt-rg \
  --server doc-mgmt-sqlserver<unique-suffix> \
  --name AllowAzureServices \
  --start-ip-address 0.0.0.0 \
  --end-ip-address 0.0.0.0
```

Grab the storage connection string:

```bash
az storage account show-connection-string \
  --name docmgmtstorage<unique-suffix> \
  --resource-group doc-mgmt-rg
```

## 2. Configure Environment Variables

Copy `.env.example` to `.env` and fill in your values:

```bash
cp .env.example .env
```

```
AZURE_STORAGE_CONNECTION_STRING=DefaultEndpointsProtocol=https;AccountName=...;AccountKey=...;EndpointSuffix=core.windows.net
AZURE_CONTAINER_NAME=documents
AZURE_SQL_CONNECTION_STRING=mssql+pymssql://sqladmin:<StrongPassword123!>@doc-mgmt-sqlserver<unique-suffix>.database.windows.net:1433/doc-mgmt-db
```

`.env` is never committed to source control — only `.env.example` is.

## 3. Run Locally

```bash
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
python main.py
```

The app starts on `http://localhost:8000`. Interactive API docs are at
`http://localhost:8000/docs`.

## 4. Sample API Requests / Responses

### Upload a document

```bash
curl -X POST http://localhost:8000/documents/upload \
  -F "uploaded_by=jane.doe" \
  -F "file=@/path/to/report.pdf"
```

```json
{
  "document_id": 1,
  "file_name": "report.pdf",
  "blob_url": "https://docmgmtstorage.blob.core.windows.net/documents/9c2f...pdf",
  "uploaded_by": "jane.doe",
  "upload_date": "2026-08-03T10:15:00",
  "file_type": "pdf"
}
```

### List all documents

```bash
curl http://localhost:8000/documents
```

```json
[
  {
    "document_id": 1,
    "file_name": "report.pdf",
    "blob_url": "https://docmgmtstorage.blob.core.windows.net/documents/9c2f...pdf",
    "uploaded_by": "jane.doe",
    "upload_date": "2026-08-03T10:15:00",
    "file_type": "pdf"
  }
]
```

### Get document by ID

```bash
curl http://localhost:8000/documents/1
```

### Download a document

```bash
curl -OJ http://localhost:8000/documents/1/download
```

### Generate a secure, time-limited share link

```bash
curl -X POST http://localhost:8000/documents/1/share \
  -H "Content-Type: application/json" \
  -d '{"expiry_minutes": 60}'
```

```json
{
  "share_url": "https://docmgmtstorage.blob.core.windows.net/documents/9c2f...pdf?sv=2025-05-05&se=2026-08-03T11%3A15%3A00Z&sr=b&sp=r&sig=...",
  "expires_at": "2026-08-03T11:15:00+00:00"
}
```

The link works for anyone who has it until `expires_at`; after that Azure
Storage rejects the SAS token automatically.

### Delete a document

```bash
curl -X DELETE http://localhost:8000/documents/1
```

```json
{ "message": "Document deleted successfully" }
```

---

## 5. Deploying to Azure App Service (optional)

```bash
az webapp up \
  --name doc-mgmt-app<unique-suffix> \
  --resource-group doc-mgmt-rg \
  --runtime "PYTHON:3.11"
```

Then set the same three environment variables as App Settings:

```bash
az webapp config appsettings set \
  --name doc-mgmt-app<unique-suffix> \
  --resource-group doc-mgmt-rg \
  --settings \
    AZURE_STORAGE_CONNECTION_STRING="..." \
    AZURE_CONTAINER_NAME="documents" \
    AZURE_SQL_CONNECTION_STRING="..."
```

## 6. Screenshots to Capture for Submission

- Successful upload response (Swagger UI `/docs` or curl output)
- `GET /documents` showing the uploaded file listed
- Blob visible inside the container in the Azure Portal
- Row visible inside the `documents` table (Azure SQL Query Editor)
- Share-link response, and the link opening the file in a browser
- Delete response, plus the blob/row gone from Azure afterward
