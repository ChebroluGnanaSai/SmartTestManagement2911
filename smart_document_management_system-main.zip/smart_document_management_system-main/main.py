"""
Smart Document Management System
---------------------------------
FastAPI application that lets users upload documents, storing the file in
Azure Blob Storage and its metadata in Azure SQL Database, then view,
download, securely share, and delete those documents.
"""

import uuid
from datetime import datetime
from pathlib import Path
from typing import List

from fastapi import Depends, FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import Response
from sqlalchemy.orm import Session

import blob_storage
from database import Document, get_db, init_db
from schemas import DocumentOut, ShareLinkRequest, ShareLinkResponse

app = FastAPI(
    title="Smart Document Management System",
    description="Upload, view, download, securely share, and delete documents "
    "backed by Azure Blob Storage + Azure SQL Database.",
)

# PDF / Image / Word documents only, per the spec.
ALLOWED_EXTENSIONS = {".pdf", ".png", ".jpg", ".jpeg", ".doc", ".docx"}

init_db()
blob_storage.init_container()


@app.get("/")
async def root():
    return {
        "message": "Smart Document Management System is running.",
        "docs": "/docs",
    }


@app.post("/documents/upload", response_model=DocumentOut, status_code=201)
async def upload_document(
    uploaded_by: str = Form(...),
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
):
    """Uploads a file to Azure Blob Storage and saves its metadata to
    Azure SQL Database."""
    extension = Path(file.filename).suffix.lower()
    if extension not in ALLOWED_EXTENSIONS:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported file type '{extension}'. "
            f"Allowed types: {', '.join(sorted(ALLOWED_EXTENSIONS))}",
        )

    file_bytes = await file.read()
    if not file_bytes:
        raise HTTPException(status_code=400, detail="Uploaded file is empty")

    # A UUID-based blob name avoids collisions between files with the same
    # original name while the human-readable name is preserved in the DB.
    blob_name = f"{uuid.uuid4()}{extension}"

    blob_url = blob_storage.upload_file(
        blob_name=blob_name,
        file_bytes=file_bytes,
        content_type=file.content_type or "application/octet-stream",
    )

    document = Document(
        file_name=file.filename,
        blob_url=blob_url,
        uploaded_by=uploaded_by,
        upload_date=datetime.utcnow(),
        file_type=extension.lstrip("."),
    )
    db.add(document)
    db.commit()
    db.refresh(document)
    return document


@app.get("/documents", response_model=List[DocumentOut])
async def list_documents(db: Session = Depends(get_db)):
    """Returns metadata for all uploaded documents."""
    return db.query(Document).order_by(Document.document_id.desc()).all()


@app.get("/documents/{document_id}", response_model=DocumentOut)
async def get_document(document_id: int, db: Session = Depends(get_db)):
    """Returns metadata for one document."""
    document = db.query(Document).filter(Document.document_id == document_id).first()
    if not document:
        raise HTTPException(status_code=404, detail="Document not found")
    return document


@app.get("/documents/{document_id}/download")
async def download_document(document_id: int, db: Session = Depends(get_db)):
    """Streams the document's bytes back as a file download."""
    document = db.query(Document).filter(Document.document_id == document_id).first()
    if not document:
        raise HTTPException(status_code=404, detail="Document not found")

    blob_name = blob_storage.blob_name_from_url(document.blob_url)
    file_bytes = blob_storage.download_file(blob_name)

    return Response(
        content=file_bytes,
        media_type="application/octet-stream",
        headers={"Content-Disposition": f'attachment; filename="{document.file_name}"'},
    )


@app.post("/documents/{document_id}/share", response_model=ShareLinkResponse)
async def share_document(
    document_id: int,
    request: ShareLinkRequest,
    db: Session = Depends(get_db),
):
    """Generates a secure, time-limited SAS URL for a document. The caller
    chooses how long the link stays valid (e.g. 5, 60, or 1440 minutes)."""
    document = db.query(Document).filter(Document.document_id == document_id).first()
    if not document:
        raise HTTPException(status_code=404, detail="Document not found")

    blob_name = blob_storage.blob_name_from_url(document.blob_url)
    share_url, expires_at = blob_storage.generate_share_link(
        blob_name, request.expiry_minutes
    )
    return ShareLinkResponse(share_url=share_url, expires_at=expires_at)


@app.delete("/documents/{document_id}")
async def delete_document(document_id: int, db: Session = Depends(get_db)):
    """Removes the file from Blob Storage and its metadata from Azure SQL."""
    document = db.query(Document).filter(Document.document_id == document_id).first()
    if not document:
        raise HTTPException(status_code=404, detail="Document not found")

    blob_name = blob_storage.blob_name_from_url(document.blob_url)
    blob_storage.delete_file(blob_name)

    db.delete(document)
    db.commit()
    return {"message": "Document deleted successfully"}


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
