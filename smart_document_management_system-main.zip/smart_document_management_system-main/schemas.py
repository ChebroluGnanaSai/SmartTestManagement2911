"""
schemas.py — Pydantic request/response models used by the API.
"""

from datetime import datetime

from pydantic import BaseModel, Field


class DocumentOut(BaseModel):
    document_id: int
    file_name: str
    blob_url: str
    uploaded_by: str
    upload_date: datetime
    file_type: str

    class Config:
        from_attributes = True


class ShareLinkRequest(BaseModel):
    # Duration the generated link stays valid for, e.g. 5 (minutes), 60 (1 hour),
    # 1440 (24 hours).
    expiry_minutes: int = Field(default=60, gt=0)


class ShareLinkResponse(BaseModel):
    share_url: str
    expires_at: datetime
